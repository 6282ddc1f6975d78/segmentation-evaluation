# Toward Interpretable Evaluation Measures for Time Series Segmentation

## Environment

A Python 3.9.18 virtual environment is recommended.

```bash
conda env create -f environment.yml
conda activate segmentation-eval
```

Note:
- Import `pyhsmm` version `0.1.1`
- PaTSS is using Java, you may need `openjdk`

## Datasets

Data is stored in `data/` folder:
```
data/
├── ActRecTut
├── MoCap
├── ...
```

## Reproduce results

Run main experiment in `multivariate` setting
```bash
python experiments.py
```
Evaluate the algorithms
```bash
python evaluation.py multivariate
```

Other experiments in `src` folder.

## Results

Results will be saved in a `results/` directory
