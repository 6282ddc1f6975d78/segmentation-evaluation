import os
import time
import json
import logging
import warnings

import scipy.io
import numpy as np
import pandas as pd
from pathlib import Path

os.environ['NUMPY_EXPERIMENTAL_DTYPE_API'] = '1'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

warnings.filterwarnings("ignore", message="using slow sample_crp_tablecounts")
np.seterr(all='warn')

from TSpy.utils import *
from TSpy.label import *

import bocd
import ruptures as rpt
import utils.load_dataset as load_dataset
from baselines.ticc.TICC_solver import TICC
from baselines.hvgh.hvgh import HVGH
from baselines.hdp_hsmm.hdp_hsmm import HDP_HSMM
from baselines.autoplait.autoplait import *
from baselines.patss.algorithms import PaTSS_perso
from claspy.segmentation import BinaryClaSPSegmentation
from baselines.clasp.test import run_clasp_multivariate
from aeon.segmentation import FLUSSSegmenter, HidalgoSegmenter

from baselines.time2state.src.time2state import Time2State
from baselines.time2state.src.adapers import *
from baselines.time2state.src.clustering import *
from baselines.time2state.src.default_params import *

from baselines.E2USD.e2usd import E2USD
from baselines.E2USD.adapers import *
from baselines.E2USD.utils import *
from baselines.E2USD.clustering import *
from baselines.E2USD.params import *
from baselines.E2USD.networks import *

from utils.metrics import *
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score

def save_prediction(analysis_type, algorithm_name, dataset_name, ts_info, prediction):
    ts_info = '_' + '_'.join(map(str, ts_info)) + '.npy'
    results_dir = Path(f'results/{analysis_type}/clustering/{algorithm_name}')
    results_dir.mkdir(parents=True, exist_ok=True)
    results_file = results_dir / (dataset_name + ts_info)
    np.save(results_file, np.array(prediction, dtype=int))

def save_results(analysis_type, results_df, dataset_name, ts_info, evaluate, groundtruth, prediction, elapsed_time):
    ts =  dataset_name + '_' + '_'.join(map(str, ts_info)) + '.npy'
    if evaluate:
        if analysis_type == 'univariate':
            f1, cov = run_evaluation(analysis_type, groundtruth, prediction)
            results_df = pd.concat([results_df, pd.DataFrame([{'dataset': ts, 'time': elapsed_time, 'f1': f1, 'covering': cov}])], ignore_index=True)
        else:
            f1, cov, nmi, ari, wari, cms = run_evaluation(analysis_type, groundtruth, prediction)
            results_df = pd.concat([results_df, pd.DataFrame([{'dataset': ts, 'time': elapsed_time, 'f1': f1, 'covering': cov, 'nmi': nmi, 'ari': ari, 'wari': wari, 'cms': cms,}])], ignore_index=True)
    else:
        results_df = pd.concat([results_df, pd.DataFrame([{'dataset': ts, 'time': elapsed_time}])], ignore_index=True)
    return results_df


def run_experiment(analysis_type, algorithm_name, dataset_name, data, evaluate=False):
    
    results_df = pd.DataFrame()

    # if analysis_type == 'univariate':

        # {
        # "dataset_path": "data",
        # "dataset_names": ["UCRSEG"],
        # "algorithms": ["fluss", "pelt", "binseg", "window", "bocd"]
        # }

        # for data, groundtruth, infos in load_dataset.load_data_debug(dataset_name, debug=False):

        #     n_states = len(set(groundtruth)) if groundtruth is not None else None
        #     data = data.flatten()
        #     prediction, elapsed_time = run_algorithm(analysis_type, algorithm_name, data, n_states=n_states)
        #     print(prediction)
        #     save_prediction(analysis_type, algorithm_name, dataset_name, infos, prediction)
        #     results_df = save_results(analysis_type, results_df, dataset_name, infos, evaluate, groundtruth, prediction, elapsed_time)

    if dataset_name == 'tssb':

        # {
        # "dataset_path": "data/tssb.csv",
        # "dataset_names": ["tssb"],
        # "algorithms": ["fluss", "pelt", "binseg", "window", "bocd"]
        # }
        results_df = pd.DataFrame(columns=['dataset', 'change_points', 'time'])
        for index, row in data.iterrows():
            # if index >= 1:
            #     break
            dataset, window_size, true_cps, data = row['dataset'], row['window_size'], row['change_points'], row['time_series']
            # window_size = np.int64(window_size)
            # change_points = np.asarray(change_points, dtype=np.int64)
            data = np.fromstring(data.strip('[]'), sep=',', dtype=np.float64)
            logging.info(f"Running algorithm: {algorithm_name} on TS: {dataset}")

            change_points, elapsed_time = run_algorithm(analysis_type, algorithm_name, data)

            results_df = pd.concat([results_df, pd.DataFrame([{'dataset': dataset, 'change_points': change_points, 'time': elapsed_time}])], ignore_index=True)
    
    else:

        config_path = Path(f"config/{algorithm_name}.json")
        with open(config_path, 'r') as config_file:
            config = json.load(config_file)
        if dataset_name in ['Suturing', 'Needle_Passing', 'Knot_Tying']:
            globals().update(config['JIGSAWS'])
        else:
            globals().update(config[dataset_name])

        for data, groundtruth, infos in load_dataset.load_data_debug(dataset_name, debug=False):

            if algorithm_name == 'ticc':
                if dataset_name in ['ActRecTut', 'PAMAP2', 'USC-HAD', 'Suturing', 'Knot_Tying', 'Needle_Passing']:
                    groundtruth = groundtruth[:-2]

                elif dataset_name == 'MoCap':
                    groundtruth = groundtruth[:-4]

            if dataset_name == 'UCRSEG':
                if algorithm_name == 'ticc':
                    groundtruth = groundtruth[win_size:]
                else:
                    groundtruth = groundtruth[:-1]
            
            n_states = len(set(groundtruth)) if groundtruth is not None else None

            prediction, elapsed_time = run_algorithm(analysis_type, algorithm_name, data, n_states=n_states)
            save_prediction(analysis_type, algorithm_name, dataset_name, infos, prediction)
            results_df = save_results(analysis_type, results_df, dataset_name, infos, evaluate, groundtruth, prediction, elapsed_time)

        # if dataset_name == 'MoCap':

        #     base_path = os.path.join('data', dataset_name, '4d/')
        #     f_list = os.listdir(base_path)
        #     f_list.sort()

        #     for idx, fname in enumerate(f_list):
        #         print('Processing file', fname)
        #         dataset_path = base_path + fname
        #         df = pd.read_csv(dataset_path, sep=' ', usecols=range(0, 4))
        #         data = df.to_numpy()
        #         groundtruth = seg_to_label(dataset_info[fname]['label'])[:-1]
        #         if algorithm_name == 'ticc':
        #             groundtruth = seg_to_label(dataset_info[fname]['label'])[:-5]
        #         if algorithm_name == 'hdp_hsmm':
        #             groundtruth = seg_to_label(dataset_info[fname]['label'])[:-1]
        #         n_states = len(set(groundtruth))
                
        #         prediction, elapsed_time = run_algorithm(analysis_type, algorithm_name, data, n_states=n_states)
                
        #         results_dir = Path(f'results/{analysis_type}/{algorithm_name}')
        #         results_dir.mkdir(parents=True, exist_ok=True)
        #         results_file = results_dir / (dataset_name + '.npy')
        #         np.save(results_file, np.array(prediction, dtype=int))

        #         if evaluate:
        #             ari, anmi, nmi, f1, covering = run_evaluation(groundtruth, prediction)
        #             results_df = pd.concat([results_df, pd.DataFrame([{'dataset': str(dataset_path), 'time': elapsed_time, 'ari': ari, 'anmi': anmi, 'nmi': nmi, 'f1': f1, 'covering': covering}])], ignore_index=True)
        #         else:
        #             results_df = pd.concat([results_df, pd.DataFrame([{'dataset': str(dataset_path), 'time': elapsed_time}])], ignore_index=True)


        # if dataset_name == 'PAMAP2':

        #     for subject_number in range(1,10):
        #         dataset_path = os.path.join('data', 'PAMAP2/Protocol/subject10' + str(subject_number) + '.dat')
        #         print(dataset_path)
        #         df = pd.read_csv(dataset_path, sep=' ', header=None)
        #         data = df.to_numpy()
        #         groundtruth = np.array(data[:,1], dtype=int)
        #         hand_acc = data[:, 4:7]
        #         chest_acc = data[:, 21:24]
        #         ankle_acc = data[:, 38:41]
        #         data = np.hstack([hand_acc, chest_acc, ankle_acc])
        #         data = fill_nan(data)
        #         data = normalize(data)

        #         # Subsample data for faster computation
        #         subsample_algorithms = ['ticc', 'hdp_hsmm', 'clasp']
        #         subsample_algorithms = []
        #         if algorithm_name in subsample_algorithms:
        #             logging.info("Remember to remove subsampling before running the final experiment.")
        #             data = data[::20]
        #             groundtruth = groundtruth[::20]

        #         if algorithm_name == 'ticc':
        #             groundtruth = groundtruth[:-2]

        #         n_states = len(set(groundtruth))

        #         prediction, elapsed_time = run_algorithm(analysis_type, algorithm_name, data, n_states=n_states)

        #         results_dir = Path(f'results/{analysis_type}/{algorithm_name}')
        #         results_dir.mkdir(parents=True, exist_ok=True)
        #         results_file = results_dir / (dataset_name + '_' + str(subject_number) + '.npy')
        #         np.save(results_file, np.array(prediction, dtype=int))

        #         if evaluate:
        #             ari, anmi, nmi, f1, covering = run_evaluation(groundtruth, prediction)
        #             results_df = pd.concat([results_df, pd.DataFrame([{'dataset': str(dataset_path), 'time': elapsed_time, 'ari': ari, 'anmi': anmi, 'nmi': nmi, 'f1': f1, 'covering': covering}])], ignore_index=True)
        #         else:
        #             results_df = pd.concat([results_df, pd.DataFrame([{'dataset': str(dataset_path), 'time': elapsed_time}])], ignore_index=True)

        # if dataset_name == 'UCRSEG':

        #     dataset_path = os.path.join('data', 'UCRSEG/')
        #     for fname in os.listdir(dataset_path):
        #         print('Processing file', fname)
        #         info_list = fname[:-4].split('_')
        #         seg_info = {}
        #         i = 0
        #         for seg in info_list[2:]:
        #             seg_info[int(seg)] = i
        #             i += 1
        #         seg_info[len_of_file(dataset_path + fname)] = i
        #         n_states = len(seg_info)
        #         df = pd.read_csv(dataset_path + fname)
        #         data = df.to_numpy()
        #         data = normalize(data)
        #         groundtruth = seg_to_label(seg_info)[:-1]

        #         if algorithm_name == 'ticc':
        #             groundtruth = seg_to_label(seg_info)[win_size:]

        #         prediction, elapsed_time = run_algorithm(analysis_type, algorithm_name, data, n_states=n_states)

        #         results_dir = Path(f'results/{analysis_type}/{algorithm_name}')
        #         results_dir.mkdir(parents=True, exist_ok=True)
        #         results_file = results_dir / (dataset_name + fname + '.npy')
        #         np.save(results_file, np.array(prediction, dtype=int))

        #         if evaluate:
        #             ari, anmi, nmi, f1, covering = run_evaluation(groundtruth, prediction)
        #             results_df = pd.concat([results_df, pd.DataFrame([{'dataset': str(dataset_path), 'time': elapsed_time, 'ari': ari, 'anmi': anmi, 'nmi': nmi, 'f1': f1, 'covering': covering}])], ignore_index=True)
        #         else:
        #             results_df = pd.concat([results_df, pd.DataFrame([{'dataset': str(dataset_path), 'time': elapsed_time}])], ignore_index=True)

        # if dataset_name == 'USC-HAD':

        #     if algorithm_name == 'e2usd' or algorithm_name == 'time2state':
        #         train, _ = load_USC_HAD(1, 1)
        #         train = normalize(train)
        #         # if algorithm_name == 'e2usd':
        #         #     e2usd, _ = run_e2usd_fit(train, in_channels, out_channels, win_size, step)
        #         # elif algorithm_name == 'time2state':
        #         #     t2s, _ = run_time2state_fit(train, in_channels, out_channels, win_size, step, M, N, nb_steps)

        #     for subject in range(1, 15):
        #         for target in range(1, 6):
        #             print('Processing subject', subject, 'target', target)
        #             data, groundtruth = load_USC_HAD(subject, target)
        #             data = normalize(data)
        #             n_states = len(set(groundtruth))
        #             if algorithm_name == 'ticc':
        #                 groundtruth = groundtruth[:-2]
        #             # if algorithm_name == 'e2usd':
        #             #     prediction = run_e2usd_predict(e2usd, data, win_size, step)
        #             # elif algorithm_name == 'time2state':
        #             #     prediction = run_time2state_predict(t2s, data, win_size, step)
                    
        #             prediction, elapsed_time = run_algorithm(analysis_type, algorithm_name, data, n_states=n_states)

        #             results_dir = Path(f'results/{analysis_type}/{algorithm_name}')
        #             results_dir.mkdir(parents=True, exist_ok=True)
        #             results_file = results_dir / (dataset_name + '_Subject' + str(subject) + '_a' + str(target) + '.npy')
        #             np.save(results_file, np.array(prediction, dtype=int))

        #             dataset_path = os.path.join('data', 'USC-HAD/Subject' + str(subject) + '/a' + str(target) + '.mat')

        #             if evaluate:
        #                 ari, anmi, nmi, f1, covering = run_evaluation(groundtruth, prediction)
        #                 results_df = pd.concat([results_df, pd.DataFrame([{'dataset': str(dataset_path), 'time': elapsed_time, 'ari': ari, 'anmi': anmi, 'nmi': nmi, 'f1': f1, 'covering': covering}])], ignore_index=True)
        #             else:
        #                 results_df = pd.concat([results_df, pd.DataFrame([{'dataset': str(dataset_path), 'time': elapsed_time}])], ignore_index=True)

        # if dataset_name == 'Suturing' or dataset_name == 'Needle_Passing' or dataset_name == 'Knot_Tying':

        #     for subject in ['B', 'C', 'D', 'E', 'F', 'G', 'H', 'I']:
        #         for trial in range(1, 6):
        #             # Missing annotation files
        #             if (dataset_name == 'Suturing' and subject == 'H' and trial == 2) or \
        #                (dataset_name == 'Knot_Tying' and ((subject == 'B' and trial == 5) or (subject == 'H' and (trial == 1 or trial == 2))) or (subject == 'I' and trial == 4)) or \
        #                (dataset_name == 'Needle_Passing' and ((subject == 'B' and trial == 5) or (subject == 'E' and trial == 2) or (subject == 'F' and (trial == 2 or trial == 5)) or (subject == 'G') or (subject == 'H' and (trial == 1 or trial == 3)) or (subject == 'I' and trial == 1))):
        #                 continue
        #             print('Processing subject', subject, 'trial', trial)
        #             data, groundtruth = jigsaws.load_data(dataset_name, subject, trial, variables=None)
        #             data = normalize(data)
        #             n_states = len(set(groundtruth))
        #             # if algorithm_name == 'ticc':
        #             #     groundtruth = groundtruth[:-2]
        #             #     continue
        #             # else:
        #             prediction, elapsed_time = run_algorithm(analysis_type, algorithm_name, data, n_states=n_states)

        #             results_dir = Path(f'results/{analysis_type}/{algorithm_name}')
        #             results_dir.mkdir(parents=True, exist_ok=True)
        #             results_file = results_dir / (dataset_name + '_' + subject + '00' + str(trial) + '.npy')
        #             np.save(results_file, np.array(prediction, dtype=int))

        #             dataset_path = os.path.join('data', dataset_name + '_' + subject + '00' + str(trial) + '.npy')

        #             if evaluate:
        #                 ari, anmi, nmi, f1, covering = run_evaluation(groundtruth, prediction)
        #                 results_df = pd.concat([results_df, pd.DataFrame([{'dataset': str(dataset_path), 'time': elapsed_time, 'ari': ari, 'anmi': anmi, 'nmi': nmi, 'f1': f1, 'covering': covering}])], ignore_index=True)
        #             else:
        #                 results_df = pd.concat([results_df, pd.DataFrame([{'dataset': str(dataset_path), 'time': elapsed_time}])], ignore_index=True)


    return results_df

# def load_USC_HAD(subject, target):
#     prefix = os.path.join('data/USC-HAD/Subject' + str(subject) + '/')
#     fname_prefix = 'a'
#     fname_postfix = 't' + str(target) + '.mat'
#     data_list = []
#     label_json = {}
#     total_length = 0
#     for i in range(1,13):
#         data = scipy.io.loadmat(prefix + fname_prefix + str(i) + fname_postfix)
#         data = data['sensor_readings']
#         data_list.append(data)
#         total_length += len(data)
#         label_json[total_length] = i
#     label = seg_to_label(label_json)
#     return np.vstack(data_list), label

def run_algorithm(analysis_type, algorithm_name, data, n_states=None):

    if algorithm_name == 'patss':
        prediction, _, elapsed_time = run_patss(data)
    if algorithm_name == 'clasp':
        prediction, elapsed_time = run_clasp(data)
    if algorithm_name == 'fluss':
        prediction, elapsed_time = run_fluss(data)
    if algorithm_name == 'pelt':
        prediction, elapsed_time = run_pelt(data)
    if algorithm_name == 'binseg':
        prediction, elapsed_time = run_binseg(data)
    if algorithm_name == 'window':
        prediction, elapsed_time = run_window(data)
    if algorithm_name == 'hidalgo':
        prediction, elapsed_time = run_hidalgo(data)
    if algorithm_name == 'bocd':
        prediction, elapsed_time = run_bocd(data)

    if algorithm_name == 'clasp':
        if analysis_type == 'univariate':
            prediction, elapsed_time = run_clasp(data)
        else:
            prediction, elapsed_time = run_clasp_multi(data, window_size=win_size, num_cps=num_cps, n_states=n_states, offset=offset)

    if algorithm_name == 'patss':
        _, prediction, elapsed_time = run_patss(data)
    if algorithm_name == 'autoplait':
        prediction, elapsed_time = run_autoplait(data)
    if algorithm_name == 'ticc':
        prediction, elapsed_time = run_ticc(data, window_size=win_size, number_of_clusters=n_states, lambda_parameter=lambda_parameter, beta=beta, threshold=threshold)
    if algorithm_name == 'hvgh':
        prediction, elapsed_time = run_hvgh(data, window_size=100)
    if algorithm_name == 'hdp_hsmm':
        prediction, elapsed_time = run_hdp_hsmm(data, alpha, beta, n_iter)
    if algorithm_name == 'time2state':
        prediction, elapsed_time = run_time2state(data, in_channels, out_channels, win_size, step, M, N, nb_steps)
    if algorithm_name == 'e2usd':
        prediction, elapsed_time = run_e2usd(data, in_channels, out_channels, win_size, step)

    return prediction, elapsed_time

def run_evaluation(analysis_type, groundtruth, prediction):

    if analysis_type == 'univariate':
        f1 = f_score(groundtruth, prediction)
        cov = covering(groundtruth, prediction)
        return f1, cov
    else:
        groundtruth = groundtruth[:len(prediction)]
        f1 = f_score(groundtruth, prediction)
        cov = covering(groundtruth, prediction)
        nmi = normalized_mutual_info_score(groundtruth, prediction)
        ari = adjusted_rand_score(groundtruth, prediction)
        wari = weighted_adjusted_rand_score(groundtruth, prediction)
        cms = common_matching_sequence(groundtruth, prediction)
        return f1, cov, nmi, ari, wari, cms
    
def run_fluss(time_series):
    start_time = time.time()
    fluss = FLUSSSegmenter(period_length=10, n_regimes=2, exclusion_factor=5)
    change_points = fluss.fit_predict(time_series)
    end_time = time.time()
    elapsed_time = end_time - start_time
    return change_points, elapsed_time

# Multivariate ONLY
def run_hidalgo(time_series):
    start_time = time.time()
    hidalgo = HidalgoSegmenter()
    change_points = hidalgo.fit_predict(time_series, axis=0).tolist()
    end_time = time.time()
    elapsed_time = end_time - start_time
    return change_points, elapsed_time

# Multivariate
def run_pelt(time_series):
    start_time = time.time()
    pelt = rpt.Pelt()
    change_points = pelt.fit_predict(time_series, pen=10)
    end_time = time.time()
    elapsed_time = end_time - start_time
    return change_points, elapsed_time

# Multivariate
def run_binseg(time_series):
    start_time = time.time()
    pelt = rpt.Binseg()
    change_points = pelt.fit_predict(time_series, pen=10)
    end_time = time.time()
    elapsed_time = end_time - start_time
    return change_points, elapsed_time

# Multivariate
def run_window(time_series):
    start_time = time.time()
    pelt = rpt.Window()
    change_points = pelt.fit_predict(time_series, pen=20)
    end_time = time.time()
    elapsed_time = end_time - start_time
    return change_points, elapsed_time

def run_bocd(time_series):
    start_time = time.time()
    bc = bocd.BayesianOnlineChangePointDetection(bocd.ConstantHazard(len(time_series)), bocd.StudentT(mu=0, kappa=1, alpha=1, beta=1))
    rt_mle = np.empty(time_series.shape)
    for i, d in enumerate(time_series):
        bc.update(d)
        rt_mle[i] = bc.rt
    change_points = np.where(np.diff(rt_mle)<0)[0].tolist()
    end_time = time.time()
    elapsed_time = end_time - start_time
    return change_points, elapsed_time

def run_patss(time_series):
    start_time = time.time()
    multivariate_time_series = PaTSS_perso.transform_to_dfs(time_series)
    length_time_series = multivariate_time_series[0].shape[0]
    segmentation, individual_embeddings, all_patterns_combined = PaTSS_perso.run_patss('baselines/patss/temp/', multivariate_time_series, length_time_series)
    single_array, change_points = PaTSS_perso.probas_to_segments_and_change_points(segmentation)
    end_time = time.time()
    elapsed_time = end_time - start_time
    return change_points, single_array, elapsed_time

def run_clasp(time_series):
    start_time = time.time()
    clasp = BinaryClaSPSegmentation()
    clasp.fit_predict(time_series)
    change_points = clasp.change_points.tolist()
    end_time = time.time()
    elapsed_time = end_time - start_time
    return change_points, elapsed_time

def run_clasp_multi(time_series, window_size, num_cps, n_states, offset):
    start_time = time.time()
    # n_states only used for clustering
    prediction = run_clasp_multivariate(time_series, window_size, num_cps, n_states, offset)
    end_time = time.time()
    elapsed_time = end_time - start_time
    return prediction, elapsed_time

def run_autoplait(time_series):
    start_time = time.time()
    time_series = scale(time_series)
    ap = AutoPlait()
    ap.solver(time_series)
    prediction = ap.predict()
    end_time = time.time()
    elapsed_time = end_time - start_time
    return prediction, elapsed_time

def run_hdp_hsmm(time_series, alpha, beta, n_iter):
    start_time = time.time()
    time_series = normalize(time_series)
    prediction = HDP_HSMM(alpha, beta, n_iter).fit(time_series)
    end_time = time.time()
    elapsed_time = end_time - start_time
    return prediction, elapsed_time

def run_hvgh(time_series, window_size=100):
    hvgh = HVGH(epoch=5, iteration=2)
    hvgh.fit(time_series, save_dir+dir_name, win_size=100)

def run_ticc(time_series, window_size, number_of_clusters, lambda_parameter, beta, threshold):
    start_time = time.time()
    ticc = TICC(window_size=window_size, number_of_clusters=number_of_clusters, lambda_parameter=lambda_parameter, beta=beta, maxIters=10, threshold=threshold,
            write_out_file=False, prefix_string="output_folder/", num_proc=10)
    prediction, _ = ticc.fit_transform(time_series)
    end_time = time.time()
    elapsed_time = end_time - start_time
    return prediction, elapsed_time

def run_time2state(time_series, in_channels, out_channels, window_size, step, M, N, nb_steps):
    start_time = time.time()
    params_LSE['in_channels'] = in_channels
    params_LSE['compared_length'] = window_size
    params_LSE['out_channels'] = out_channels
    params_LSE['win_size'] = window_size
    params_LSE['M'] = M
    params_LSE['N'] = N
    params_LSE['nb_steps'] = nb_steps
    t2s = Time2State(window_size, step, CausalConv_LSE_Adaper(params_LSE), DPGMM(None)).fit(time_series, window_size, step)
    prediction = t2s.state_seq
    end_time = time.time()
    elapsed_time = end_time - start_time
    return prediction, elapsed_time

def run_time2state_fit(time_series, in_channels, out_channels, window_size, step, M, N, nb_steps):
    start_time = time.time()
    params_LSE['in_channels'] = in_channels
    params_LSE['compared_length'] = window_size
    params_LSE['out_channels'] = out_channels
    params_LSE['win_size'] = window_size
    params_LSE['M'] = M
    params_LSE['N'] = N
    params_LSE['nb_steps'] = nb_steps
    t2s = Time2State(window_size, step, CausalConv_LSE_Adaper(params_LSE), DPGMM(None)).fit(time_series, window_size, step)
    end_time = time.time()
    elapsed_time = end_time - start_time
    return t2s, elapsed_time

def run_time2state_predict(t2s, time_series, window_size, step):
    start_time = time.time()
    t2s.predict(time_series, window_size, step)
    prediction = t2s.state_seq
    end_time = time.time()
    elapsed_time = end_time - start_time
    return prediction, elapsed_time

def run_e2usd(time_series, in_channels, out_channels, window_size, step):
    start_time = time.time()
    params['in_channels'] = in_channels
    params['compared_length'] = window_size
    params['out_channels'] = out_channels
    e2usd = E2USD(window_size, step, E2USD_Adaper(params), DPGMM(None)).fit(time_series, window_size, step)
    prediction = e2usd.state_seq
    end_time = time.time()
    elapsed_time = end_time - start_time
    return prediction, elapsed_time

def run_e2usd_fit(time_series, in_channels, out_channels, window_size, step):
    start_time = time.time()
    params['in_channels'] = in_channels
    params['compared_length'] = window_size
    params['out_channels'] = out_channels
    e2usd = E2USD(window_size, step, E2USD_Adaper(params), DPGMM(None)).fit(time_series, window_size, step)
    end_time = time.time()
    elapsed_time = end_time - start_time
    return e2usd, elapsed_time

def run_e2usd_predict(e2usd, time_series, window_size, step):
    start_time = time.time()
    e2usd.predict(time_series, window_size, step)
    prediction = e2usd.state_seq
    end_time = time.time()
    elapsed_time = end_time - start_time
    return prediction, elapsed_time