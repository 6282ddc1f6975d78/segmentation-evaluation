import sys
import os
import json
import argparse # Import argparse
# import numpy as np # Removed unused import
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches # Import patches for legend
import seaborn as sns

# Helper function (if needed elsewhere, otherwise can be removed if not used)
# def str_to_list(string):
#     if string == '[]':
#         return []
#     else:
#         return list(map(int, string.strip('[]').split(',')))

def generate_plot(plot_type, data, x_var, y_var, hue_var, x_order, hue_order, x_label, hue_label, title, style, palette_map, fig_width, fig_height, output_path, y_lim=None, show_legend=True):
    """
    Generates and saves a boxplot or barplot with color only or color + symbols (hatches),
    using a fixed color map for hues, optional fixed y-axis limits, and controllable legend visibility.
    """
    print(f"Generating {plot_type}: {title} (Style: {style}, Legend: {show_legend})")
    plt.figure(figsize=(fig_width, fig_height))
    ax = plt.gca() # Get current axes

    # Define hatch patterns for 'symbols' style
    hatches = ['/', '\\', '|', '-', '+', 'x', 'o', 'O', '.', '*'] # Cycle through these hatches

    plot_function = None
    plot_kwargs = {} # Additional arguments specific to plot type if needed
    if plot_type == 'boxplot':
        plot_function = sns.boxplot
        y_axis_label = 'Score'
    elif plot_type == 'barplot':
        plot_function = sns.barplot
        # Remove error bars for barplot using the older 'ci' parameter for compatibility
        plot_kwargs = {'ci': None}
        y_axis_label = 'Mean Score' # More specific for barplot
    else:
        raise ValueError(f"Invalid plot_type: {plot_type}. Choose 'boxplot' or 'barplot'.")

    # --- Generate the base plot ---
    # Use the provided palette_map dictionary for consistent hue coloring
    plot_function(data=data, x=x_var, y=y_var, hue=hue_var,
                  order=x_order, hue_order=hue_order, palette=palette_map, ax=ax, **plot_kwargs)

    # --- Handle Style (Color vs Symbols) ---
    handles, labels = ax.get_legend_handles_labels() # Get default handles first

    if style == 'symbols':
        num_hues = len(hue_order) if hue_order else 0
        hatches_applied = False

        # Ensure patches are accessible and iterate through them
        if hasattr(ax, 'patches') and ax.patches and num_hues > 0:
            expected_patches = len(x_order) * len(hue_order) if x_order and hue_order else 0
            actual_patches = len(ax.patches)
            if plot_type == 'barplot' and actual_patches > expected_patches:
                 print(f"Warning: More patches ({actual_patches}) than expected ({expected_patches}). Hatching might be misaligned.")
            elif plot_type == 'boxplot' and actual_patches % num_hues != 0:
                 print(f"Warning: Number of patches ({actual_patches}) is not an exact multiple of hues ({num_hues}). Hatching on plot might be affected if data is sparse or zero.")

            # Apply hatches to existing patches
            for i, patch in enumerate(ax.patches):
                hue_index = i % num_hues
                hatch = hatches[hue_index % len(hatches)] # Cycle through hatches
                patch.set_hatch(hatch)
                patch.set_edgecolor('black') # Ensure edges are visible
                hatches_applied = True

            # Create custom legend handles using palette colors and hatches
            if hatches_applied:
                custom_handles = []
                custom_labels = hue_order # Use the provided hue order for labels

                # Get the colors directly from the provided palette_map
                for i, label in enumerate(custom_labels):
                    hatch = hatches[i % len(hatches)] # Match hatch to the hue order index
                    face_color = palette_map.get(label) # Get color from the fixed map

                    if face_color is None:
                        print(f"Warning: Hue label '{label}' not found in provided palette_map. Using white for legend.")
                        face_color = 'white' # Fallback color

                    # Create a patch representing the color and hatch pattern
                    legend_patch = mpatches.Patch(facecolor=face_color, edgecolor='black', hatch=hatch, label=label)
                    custom_handles.append(legend_patch)

                # Use the custom handles/labels if created successfully
                handles = custom_handles
                labels = custom_labels
            else:
                print("Warning: Could not apply hatches or determine colors for custom legend. Using default legend.")

        else:
             print("Warning: Could not find patches on the axes or no hues defined. Cannot apply hatches or create custom legend.")

    elif style == 'color':
        # For 'color' style, ensure the legend uses the correct colors from the map
        # Recreate handles/labels using the palette_map if hue_var is the algorithm
        # This ensures legend colors match the plot even if seaborn's default handles are different
        if hue_var == 'algorithm' and hue_order: # Check if hue represents algorithm
             custom_handles = []
             custom_labels = hue_order
             for label in custom_labels:
                 color = palette_map.get(label)
                 if color:
                     custom_handles.append(mpatches.Patch(color=color, label=label))
                 else:
                     print(f"Warning: Algorithm '{label}' not found in palette_map for legend.")
                     # Add a default patch or skip
                     custom_handles.append(mpatches.Patch(color='grey', label=f"{label} (color missing)")) # Indicate missing color

             if custom_handles:
                 handles = custom_handles
                 labels = custom_labels
        # Otherwise, the default handles/labels might be sufficient, but using the map is safer
        pass # Default handles/labels might be okay, but the above block improves consistency
    else:
        raise ValueError(f"Invalid style: {style}. Choose 'color' or 'symbols'.")


    # --- Final Plot Adjustments ---
    plt.title(title, fontsize=40) # Increased
    plt.xlabel("", fontsize=35) # Increased
    plt.ylabel("", fontsize=35) # Increased
    plt.xticks(rotation=45, ha='right', fontsize=35) # Increased
    plt.yticks(fontsize=35) # Increased

    if y_lim:
        ax.set_ylim(y_lim) # Set y-axis limits if provided

    # --- Legend Handling ---
    if show_legend: # Check the flag passed from main()
        # Capitalize the legend title if it exists
        capitalized_hue_label = hue_label.capitalize() if hue_label else None

        if handles and labels:
            # Ensure labels match handles if custom handles were created
            final_labels = [h.get_label() for h in handles] if hasattr(handles[0], 'get_label') else labels

            # Default legend placement (inside the plot)
            plt.legend(handles=handles, labels=final_labels, title=capitalized_hue_label,
                       loc='best', # Place legend inside the plot area
                       title_fontsize=22, fontsize=20) # Increased legend font sizes
        elif capitalized_hue_label: # Attempt to show legend title even if handles/labels failed
            print("Warning: No handles or labels generated/found for the legend, but showing title.")
            plt.legend(title=capitalized_hue_label, loc='best',
                       title_fontsize=22, fontsize=20)
        else:
            print("Warning: No handles, labels, or hue_label provided for the legend.")
    else:
        # If show_legend is False, explicitly remove any existing legend
        if ax.get_legend() is not None:
            ax.get_legend().remove()


    plt.tight_layout() # Apply tight layout

    # --- Save Figure ---
    output_dir = os.path.dirname(output_path)
    if not os.path.exists(output_dir):
        print(f"Creating directory: {output_dir}")
        os.makedirs(output_dir)

    try:
        # bbox_inches='tight' is useful for layout adjustments
        plt.savefig(output_path, bbox_inches='tight')
        print(f"Saved plot: {output_path}")
    except Exception as e:
        print(f"Error saving plot to {output_path}: {e}")

    plt.close() # Close the figure to free memory


def generate_standalone_legend(legend_items, title, palette_map, style, output_path):
    """
    Generates and saves a figure containing only the legend.
    """
    print(f"Generating standalone legend (Style: {style})")
    hatches = ['/', '\\', '|', '-', '+', 'x', 'o', 'O', '.', '*'] # Consistent hatches
    custom_handles = []
    custom_labels = legend_items

    for i, label in enumerate(custom_labels):
        face_color = palette_map.get(label)
        if face_color is None:
            print(f"Warning: Label '{label}' not found in palette_map for standalone legend. Using white.")
            face_color = 'white'

        if style == 'symbols':
            hatch = hatches[i % len(hatches)]
            legend_patch = mpatches.Patch(facecolor=face_color, edgecolor='black', hatch=hatch, label=label)
        elif style == 'color':
            legend_patch = mpatches.Patch(color=face_color, label=label)
        else:
            raise ValueError(f"Invalid style for legend: {style}")
        custom_handles.append(legend_patch)

    if not custom_handles:
        print("Error: No legend handles generated. Cannot create standalone legend.")
        return

    # Create a figure specifically for the legend
    # Estimate figure height based on number of items (adjust multiplier as needed)
    # Estimate width based on title/label length (can be tricky, start fixed)
    num_items = len(custom_handles)
    fig_height_est = 0.5 + num_items * 0.4 # Base height + height per item
    fig_width_est = 4 # Start with a reasonable width

    fig = plt.figure(figsize=(fig_width_est, fig_height_est))

    # Add the legend to the figure, centered, without a frame
    legend = fig.legend(handles=custom_handles, labels=custom_labels,
                        title=title.capitalize() if title else None,
                        loc='center', # Center the legend in the figure
                        frameon=False, # No border around the legend
                        title_fontsize=22, fontsize=20)

    # --- Save Figure ---
    output_dir = os.path.dirname(output_path)
    if not os.path.exists(output_dir):
        print(f"Creating directory: {output_dir}")
        os.makedirs(output_dir)

    try:
        # Use bbox_inches='tight' and pad_inches to crop whitespace around the legend
        fig.savefig(output_path, bbox_inches='tight', pad_inches=0.1)
        print(f"Saved standalone legend: {output_path}")
    except Exception as e:
        print(f"Error saving standalone legend to {output_path}: {e}")

    plt.close(fig) # Close the figure


def main():
    # --- Argument Parsing ---
    parser = argparse.ArgumentParser(description="Generate evaluation figures for state detection experiments.")
    parser.add_argument("experiment", help="Name of the experiment (currently forced to 'multivariate').")
    parser.add_argument("--plot_type", choices=['boxplot', 'barplot'], default='boxplot',
                        help="Type of plot to generate: 'boxplot' or 'barplot'. Default: boxplot.")
    parser.add_argument("--plot_orientation", choices=['algo_on_x', 'metric_on_x'], default='algo_on_x',
                        help="Orientation of the plot: 'algo_on_x' (algorithms on x-axis, metrics as hue) or "
                             "'metric_on_x' (metrics on x-axis, algorithms as hue). Default: algo_on_x.")
    parser.add_argument("--style", choices=['color', 'symbols'], default='color',
                        help="Plot style: 'color' for standard seaborn palettes, 'symbols' for color plus hatch patterns. Default: color.")
    parser.add_argument("--palette", default='tab10',
                        help="Seaborn color palette name to use for plots (e.g., 'tab10', 'viridis', 'Set2'). Used in both 'color' and 'symbols' styles. Default: tab10.")
    args = parser.parse_args()

    experiment = args.experiment
    plot_type = args.plot_type
    plot_orientation = args.plot_orientation
    plot_style = args.style
    palette_name = args.palette

    if experiment != 'multivariate':
        print("Warning: This script is modified to only run for the 'multivariate' experiment.")
        experiment = 'multivariate'

    config_path = os.path.join("config", f"config_{experiment}.json")
    if not os.path.exists(config_path):
        print(f"Error: Config file '{config_path}' not found.")
        sys.exit(1)

    with open(config_path, 'r') as config_file:
        config = json.load(config_file)

    script_dir = os.path.dirname(__file__)
    figures_dir = os.path.abspath(os.path.join(script_dir, "..", "figures"))
    plot_type_base_dir = os.path.join(figures_dir, plot_type)

    if not os.path.exists(figures_dir):
        print(f"Creating figures directory: {figures_dir}")
        os.makedirs(figures_dir)
    if not os.path.exists(plot_type_base_dir):
        print(f"Creating {plot_type} directory: {plot_type_base_dir}")
        os.makedirs(plot_type_base_dir)

    metrics_to_plot = ['ari', 'nmi', 'wari', 'wnmi', 'sms']
    algo_order_pref = ["e2usd", "time2state", "ticc", "hdp_hsmm", "clasp", "patss"]
    algo_order_pref_upper = [a.upper() for a in algo_order_pref] # Capitalized version for matching

    # --- Create a fixed color map for algorithms ---
    # Generate enough colors for all preferred algorithms using the chosen palette
    try:
        palette = sns.color_palette(palette_name, n_colors=len(algo_order_pref_upper))
        algo_color_map = {algo: color for algo, color in zip(algo_order_pref_upper, palette)}
        print(f"Generated color map for algorithms using palette '{palette_name}':")
        # for algo, color in algo_color_map.items(): # Optional: print the map
        #     print(f"  {algo}: {color}")
    except Exception as e:
        print(f"Error generating color palette '{palette_name}': {e}. Falling back to default.")
        # Fallback or exit if palette is crucial
        palette = sns.color_palette('tab10', n_colors=len(algo_order_pref_upper))
        algo_color_map = {algo: color for algo, color in zip(algo_order_pref_upper, palette)}


    # --- Multivariate Experiment Processing ---
    if experiment == 'multivariate':
        print(f"\nProcessing multivariate experiment (Plot type: {plot_type}, Orientation: {plot_orientation}, Style: {plot_style}, Palette: {palette_name})...")

        # Flag to track if we need to generate the standalone legend
        processed_barplot_metric_on_x = False

        for dataset in config["dataset_names"]:
            print(f"--- Processing dataset: {dataset} ---")
            all_dataset_results = []

            for algorithm in config["algorithms"]:
                # Check against lower case preference list first
                if algorithm.lower() in algo_order_pref:
                    results_path = os.path.join("results", experiment, "score", algorithm, dataset + ".csv")
                    if not os.path.exists(results_path):
                        print(f"Skipping: Results file not found for algo '{algorithm}', dataset '{dataset}' at '{results_path}'.")
                        continue
                    try:
                        results_df = pd.read_csv(results_path)
                        if results_df.empty:
                            print(f"Skipping: Results file is empty for algo '{algorithm}', dataset '{dataset}'.")
                            continue
                        # Use the original algorithm name case from config for consistency before upper()
                        results_df['algorithm'] = algorithm
                        cols_found = [m for m in metrics_to_plot if m in results_df.columns]
                        if not cols_found:
                             print(f"Skipping: None of the target metrics {metrics_to_plot} found in '{results_path}'.")
                             continue
                        cols_to_keep = cols_found + ['algorithm']
                        df_subset = results_df[cols_to_keep].copy()
                        for col in cols_found:
                            df_subset[col] = pd.to_numeric(df_subset[col], errors='coerce')
                        all_dataset_results.append(df_subset)
                    except Exception as e:
                        print(f"Error reading or processing file {results_path}: {e}")
                        continue
                else:
                    print(f"Skipping algorithm '{algorithm}' as it's not in the preferred list: {algo_order_pref}")


            if not all_dataset_results:
                print(f"No valid results collected for dataset: {dataset}. Skipping plot generation.")
                continue

            combined_df = pd.concat(all_dataset_results, ignore_index=True)
            metrics_present_in_data = [m for m in metrics_to_plot if m in combined_df.columns]
            if not metrics_present_in_data:
                print(f"No target metrics found in the combined data for dataset: {dataset}. Skipping plot generation.")
                continue

            melted_df = pd.melt(combined_df,
                                id_vars=['algorithm'],
                                value_vars=metrics_present_in_data,
                                var_name='metric',
                                value_name='score')
            melted_df.dropna(subset=['score'], inplace=True)

            if melted_df.empty:
                print(f"No valid numeric scores to plot for dataset: {dataset} after processing.")
                continue

            melted_df['algorithm'] = melted_df['algorithm'].str.upper()
            melted_df['metric'] = melted_df['metric'].str.upper()

            # Use the predefined capitalized order
            metric_order_upper = [m.upper() for m in metrics_to_plot]

            present_algos_upper = sorted(melted_df['algorithm'].unique())
            present_metrics_upper = sorted(melted_df['metric'].unique())

            # --- Configure Plot based on Orientation ---
            current_palette_map = algo_color_map # Default to the full map
            hue_is_algo = False
            is_target_case_for_no_legend = (plot_type == 'barplot' and plot_orientation == 'metric_on_x')
            if is_target_case_for_no_legend:
                processed_barplot_metric_on_x = True # Mark that we encountered this case

            if plot_orientation == 'algo_on_x':
                x_var, hue_var = 'algorithm', 'metric'
                x_label, hue_label = 'Algorithm', 'Metric'
                x_order = [algo for algo in algo_order_pref_upper if algo in present_algos_upper]
                x_order.extend(sorted([algo for algo in present_algos_upper if algo not in x_order]))
                hue_order = [metric for metric in metric_order_upper if metric in present_metrics_upper]
                hue_order.extend(sorted([metric for metric in present_metrics_upper if metric not in hue_order]))
                figure_suffix = "algo_vs_metric"
                fig_width, fig_height = 18, 10 # Adjusted width slightly
                # When metric is hue, we need a map from metric name to color
                # Generate a temporary map for metrics using the chosen palette name
                try:
                    metric_palette = sns.color_palette(palette_name, n_colors=len(hue_order))
                    current_palette_map = {metric: color for metric, color in zip(hue_order, metric_palette)}
                except Exception as e:
                     print(f"Error generating palette for metrics: {e}. Using default.")
                     metric_palette = sns.color_palette('tab10', n_colors=len(hue_order))
                     current_palette_map = {metric: color for metric, color in zip(hue_order, metric_palette)}


            elif plot_orientation == 'metric_on_x':
                x_var, hue_var = 'metric', 'algorithm'
                x_label, hue_label = 'Metric', 'Algorithm'
                hue_is_algo = True # Hue represents algorithms, use the fixed algo_color_map
                x_order = [metric for metric in metric_order_upper if metric in present_metrics_upper]
                x_order.extend(sorted([metric for metric in present_metrics_upper if metric not in x_order]))

                # --- Custom Algorithm Order for metric_on_x barplot ---
                # Determine hue_order based on SMS score for barplots, otherwise use preference
                # This hue_order is used for plotting, the standalone legend will use algo_order_pref_upper
                if plot_type == 'barplot':
                    sms_metric_name = 'SMS'
                    if sms_metric_name in present_metrics_upper:
                        sms_scores = melted_df[melted_df['metric'] == sms_metric_name]
                        if not sms_scores.empty:
                            algo_sms_means = sms_scores.groupby('algorithm')['score'].mean().sort_values(ascending=False)
                            hue_order_sms_sorted = algo_sms_means.index.tolist()
                            # Filter hue_order_sms_sorted to only include algorithms present in the current dataset
                            hue_order = [algo for algo in hue_order_sms_sorted if algo in present_algos_upper]
                            # Add any remaining present algorithms that might not have had SMS scores (or were tied)
                            hue_order.extend(sorted([algo for algo in present_algos_upper if algo not in hue_order]))
                            print(f"Dataset {dataset}: Using SMS-based algorithm order for hue: {hue_order}")
                        else:
                            print(f"Warning: No SMS scores found for dataset {dataset}. Using default algorithm order.")
                            # Fallback: Use preferred order, then alphabetical for remaining present algos
                            hue_order = [algo for algo in algo_order_pref_upper if algo in present_algos_upper]
                            hue_order.extend(sorted([algo for algo in present_algos_upper if algo not in hue_order]))
                    else:
                        print(f"Warning: SMS metric not present for dataset {dataset}. Using default algorithm order.")
                        # Fallback: Use preferred order, then alphabetical for remaining present algos
                        hue_order = [algo for algo in algo_order_pref_upper if algo in present_algos_upper]
                        hue_order.extend(sorted([algo for algo in present_algos_upper if algo not in hue_order]))
                else: # For boxplot or if barplot conditions aren't met
                    # Use preferred order, then alphabetical for remaining present algos
                    hue_order = [algo for algo in algo_order_pref_upper if algo in present_algos_upper]
                    hue_order.extend(sorted([algo for algo in present_algos_upper if algo not in hue_order]))
                # --- End Custom Algorithm Order ---

                figure_suffix = "metric_vs_algo"
                fig_width, fig_height = 12, 10
                # Ensure the algo_color_map is used
                current_palette_map = algo_color_map

            else:
                print(f"Error: Invalid plot orientation '{plot_orientation}'.")
                continue

            # --- Define Output Path ---
            style_suffix = f"_{plot_style}"
            orientation_style_dir = os.path.join(plot_type_base_dir, f"{figure_suffix}{style_suffix}")
            base_figure_filename = f"{dataset}_{plot_type}"
            pdf_figure_path = os.path.join(orientation_style_dir, f"{base_figure_filename}.pdf")

            # --- Determine Plot Settings ---
            # Legend is OFF for barplot + metric_on_x case, ON otherwise (e.g., for UCRSEG boxplot)
            show_plot_legend = not is_target_case_for_no_legend
            # Example: If you still wanted UCRSEG to have a legend in other cases:
            # show_plot_legend = (not is_target_case_for_no_legend) and (dataset.upper() == "UCRSEG")
            # Or simply always show legend unless it's the specific barplot case:
            # show_plot_legend = not is_target_case_for_no_legend

            # Fixed Y-axis scale (0 to 1.05) only for barplots
            y_axis_limit = (0, 1.05) if plot_type == 'barplot' else None

            # --- Generate Plot using the function ---
            generate_plot(
                plot_type=plot_type,
                data=melted_df,
                x_var=x_var,
                y_var='score',
                hue_var=hue_var,
                x_order=x_order,
                hue_order=hue_order, # Use the potentially SMS-sorted order for the plot itself
                x_label=x_label,
                hue_label=hue_label,
                title=dataset, # Keep title clean
                style=plot_style,
                palette_map=current_palette_map, # Pass the appropriate color map
                fig_width=fig_width,
                fig_height=fig_height,
                output_path=pdf_figure_path,
                y_lim=y_axis_limit, # Pass the y-limit (None for boxplot, fixed for barplot)
                show_legend=show_plot_legend # Control legend visibility
            )

        print(f"\nFinished processing multivariate experiment datasets.")

        # --- Generate Standalone Legend if needed ---
        if processed_barplot_metric_on_x:
            print("\nGenerating standalone legend for barplot metric_on_x case...")
            style_suffix = f"_{plot_style}"
            # Place legend in the corresponding orientation/style directory
            orientation_style_dir = os.path.join(plot_type_base_dir, f"metric_vs_algo{style_suffix}")
            legend_output_path = os.path.join(orientation_style_dir, f"standalone_legend_{plot_style}.pdf")

            # Use the preferred algorithm order for the standalone legend for consistency
            generate_standalone_legend(
                legend_items=algo_order_pref_upper, # Use the master preferred order
                title='Algorithm', # Legend title
                palette_map=algo_color_map, # The master algorithm color map
                style=plot_style,
                output_path=legend_output_path
            )

        print(f"\nAll processing finished. Figures saved in subdirectories within '{plot_type_base_dir}'.")


if __name__ == "__main__":
    main()
