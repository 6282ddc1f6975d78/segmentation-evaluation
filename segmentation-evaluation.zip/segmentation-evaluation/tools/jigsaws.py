import os
import re
import numpy as np
import pandas as pd

'''
This module provides utilities for loading and processing JIGSAWS dataset time series and groundtruth data.
Functions:
    load_ts(dataset_id, variables=None):
        Loads time series data for a given dataset ID.
        Parameters:
            dataset_id (str): The ID of the dataset to load.
            variables (list of str, optional): List of variable names to load. If None, all variables are loaded.
        Returns:
            np.ndarray: The loaded time series data.
    load_gt(dataset_id):
        Loads groundtruth gesture data for a given dataset ID.
        Parameters:
            dataset_id (str): The ID of the dataset to load.
        Returns:
            tuple: A tuple containing:
                - np.ndarray: The gesture array with gesture labels for each time step.
                - list: A list of unique gestures in the order they appear.
    load_data(dataset_id, variables=None):
        Loads both time series and groundtruth data for a given dataset ID.
        Parameters:
            dataset_id (str): The ID of the dataset to load.
            variables (list of str, optional): List of variable names to load. If None, all variables are loaded.
        Returns:
            tuple: A tuple containing:
                - np.ndarray: The loaded time series data.
                - np.ndarray: The gesture array with gesture labels for each time step.
'''

# Folder paths

data_folder = 'data'
dataset_ts = 'kinematics/AllGestures'
dataset_gt = 'transcriptions'

# Variables in the datasets

'''
1-3    (3) : Master left tooltip xyz                    
4-12   (9) : Master left tooltip R    
13-15  (3) : Master left tooltip trans_vel x', y', z'   
16-18  (3) : Master left tooltip rot_vel                
19     (1) : Master left gripper angle                  
20-38  (19): Master right
39-41  (3) : Slave left tooltip xyz
42-50  (9) : Slave left tooltip R
51-53  (3) : Slave left tooltip trans_vel x', y', z'   
54-56  (3) : Slave left tooltip rot_vel
57     (1) : Slave left gripper angle                   
58-76  (19): Slave right
'''

# Load time series data

def load_ts(dataset_name, subject_id, trial_id, variables=None):
    dataset_id = f'{dataset_name}_{subject_id}00{trial_id}'
    dataset_name = '_'.join(dataset_id.rsplit('_', 1)[:-1])
    dataset_path = os.path.join(data_folder, dataset_name, dataset_ts, dataset_id + '.txt')

    df = pd.read_csv(dataset_path, sep=r'\s+', header=None)
    
    if variables:
        # Define the column ranges for the desired variables
        variable_ranges = {
            'master_left_tooltip_xyz': list(range(0, 3)),
            'master_left_tooltip_r': list(range(3, 12)),
            'master_left_tooltip_trans_vel': list(range(12, 15)),
            'master_left_tooltip_rot_vel': list(range(15, 18)),
            'master_left_gripper_angle': [18],
            'master_right_tooltip_xyz': list(range(19, 22)),
            'master_right_tooltip_r': list(range(22, 31)),
            'master_right_tooltip_trans_vel': list(range(31, 34)),
            'master_right_tooltip_rot_vel': list(range(34, 37)),
            'master_right_gripper_angle': [37],
            'slave_left_tooltip_xyz': list(range(38, 41)),
            'slave_left_tooltip_r': list(range(41, 50)),
            'slave_left_tooltip_trans_vel': list(range(50, 53)),
            'slave_left_tooltip_rot_vel': list(range(53, 56)),
            'slave_left_gripper_angle': [56],
            'slave_right_tooltip_xyz': list(range(57, 60)),
            'slave_right_tooltip_r': list(range(60, 69)),
            'slave_right_tooltip_trans_vel': list(range(69, 72)),
            'slave_right_tooltip_rot_vel': list(range(72, 75)),
            'slave_right_gripper_angle': [75]
        }
        
        # Get the columns for the desired variables
        columns = []
        for var in variables:
            columns.extend(variable_ranges[var])
    
        ts = df.iloc[:, columns].to_numpy()

    else:
        ts = df.to_numpy()

    return ts


# Load groundtruth (gesture) data

"""
Example of gesture data
45 85 G12
86 185 G13
186 291 G13
"""

def load_gt(dataset_name, subject_id, trial_id, variables=None):
    dataset_id = f'{dataset_name}_{subject_id}00{trial_id}'
    groundtruth_path = os.path.join(data_folder, dataset_name, dataset_gt, dataset_id + '.txt')

    with open(groundtruth_path, 'r') as file:
        gesture_data = file.read()

    lines = gesture_data.strip().split('\n')
    max_index = max(int(line.split()[1]) for line in lines)
    gesture_array = np.zeros(max_index + 1, dtype=int)

    for line in lines:
        start, end, gesture = line.split()
        start, end = int(start), int(end)
        gesture_num = int(re.findall(r'\d+', gesture)[0])
        gesture_array[start:end+1] = gesture_num

    gestures = [gesture_array[0]]
    for i in range(1, len(gesture_array)):
        if gesture_array[i] != gesture_array[i-1]:
            gestures.append(gesture_array[i])

    return gesture_array, gestures


# Load time series and groundtruth data

def load_data(dataset_name, subject_id, trial_id, variables=None):
    gt, _ = load_gt(dataset_name, subject_id, trial_id)
    # Remove leading and trailing zeros
    first_annotated_time = np.nonzero(gt)[0][0]
    last_annotated_time = np.nonzero(gt)[0][-1]
    gt = gt[first_annotated_time:last_annotated_time]
    ts = load_ts(dataset_name, subject_id, trial_id, variables)
    ts = ts[first_annotated_time:last_annotated_time]
    return ts, gt