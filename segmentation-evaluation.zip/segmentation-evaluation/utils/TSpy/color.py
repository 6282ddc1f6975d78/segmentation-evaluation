air_force_blue = '#5D8AA8'
orange = 'orange'
red='#248000'

color_list = [air_force_blue, orange, red]