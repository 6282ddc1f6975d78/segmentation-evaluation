import numpy as np

import scipy.sparse as sp                                                                               # Supplementary packages for WARI
from scipy.optimize import linear_sum_assignment                                                        # Supplementary packages for SMS
from sklearn.metrics.cluster._supervised import mutual_info_score, entropy, _generalized_average        # Supplementary packages for WNMI

'''
F1 & Covering scores
Code adapted from TSSB (time-series-segmentation-benchmark)
https://github.com/ermshaua/time-series-segmentation-benchmark/blob/95a62b8e1e4e380313f187544c38f3400c1773e5/tssb/evaluation.py
Athors: Van den Burg, G.J.J. and Williams, C.K.I. from The Alan Turing Institute
'''

#------------------------------------------------------
# F1 score with margin, adapted from TSSB code
#------------------------------------------------------

def true_positives(T, X, margin=5):
    """
    Compute true positives without double counting.
    
    Parameters
    ----------
    T : iterable
        True change-point locations.
    X : iterable
        Predicted change-point locations.
    margin : int, optional
        Maximum allowed distance between a true and a predicted change-point.
        
    Returns
    -------
    set
        A set of true change-points that have been matched.
    """
    X = set(X)  # make a copy so we don't modify the original
    TP = set()
    for tau in T:
        # Find all predictions x that are within the margin of tau
        close = [(abs(tau - x), x) for x in X if abs(tau - x) <= margin]
        close.sort()  # choose the closest one
        if not close:
            continue
        _, xstar = close[0]
        TP.add(tau)
        X.remove(xstar)  # remove the matched prediction to avoid double counting
    return TP

def f_score(annotation, predictions, margin=None, alpha=0.5, return_PR=False):
    """
    Compute the F-measure for a single set of annotations.
    
    Both the annotation and predictions should be iterables of change-point 
    locations (0-based indices). The value 0 is always included by default.
    
    Parameters
    ----------
    annotation : iterable
        An iterable of true change-point locations.
    predictions : iterable
        An iterable of predicted change-point locations.
    margin : int, optional
        Maximum allowed distance between a true and predicted change-point.
    alpha : float, optional
        Weighting factor; alpha=0.5 corresponds to the F1-measure.
    return_PR : bool, optional
        If True, return a tuple (F, precision, recall). Otherwise, only F.
        
    Returns
    -------
    float or tuple
        The F-measure (and optionally precision and recall).
        
    Examples
    --------
    >>> f_score([10, 20], [10, 20])
    1.0
    >>> f_score([10, 20], [20])
    0.8  # approximately
    """

    annotation = labels_to_change_points(annotation)
    predictions = labels_to_change_points(predictions)

    if margin is None:
        margin = int(0.01 * len(annotation))

    # Ensure that 0 is included in both true annotations and predictions
    T = set(annotation)
    T.add(0)
    
    X = set(predictions)
    X.add(0)
    
    # Compute true positives
    TP = true_positives(T, X, margin=margin)
    
    # Compute precision and recall
    P = len(TP) / len(X)
    R = len(TP) / len(T)
    
    # Compute the F-measure using the weighted harmonic mean
    F = P * R / (alpha * R + (1 - alpha) * P)
    
    if return_PR:
        return F, P, R
    return F

#------------------------------------------------------
# Covering score, adaptation from TSSB & optimized version
#------------------------------------------------------

def labels_to_change_points(labels):
    """
    Convert label sequence into change points (CPs).
    
    Parameters:
        labels (list or np.array): Label sequence.
    
    Returns:
        list: Change points (CPs) including start (0) and end (n+1).
    """
    n = len(labels)
    cp_indices = [0]  # Start at index 0
    for i in range(1, n):
        if labels[i] != labels[i - 1]:  # Detect change in labels
            cp_indices.append(i)
    cp_indices.append(n)  # Include last segment boundary
    return cp_indices

def compute_segments(cp_indices):
    """
    Convert change points to segment intervals.
    
    Parameters:
        cp_indices (list): List of change points.
    
    Returns:
        list: List of segment tuples (start, end).
    """
    return [(cp_indices[i], cp_indices[i + 1]) for i in range(len(cp_indices) - 1)]

def covering_naive(ground_truth_labels, predicted_labels):
    """
    Compute the covering score for segmentation based on the given formula.
    
    Parameters:
        ground_truth_labels (list or np.array): Ground truth labels.
        predicted_labels (list or np.array): Predicted labels.
    
    Returns:
        float: Covering score.
    """
    n = len(ground_truth_labels)
    
    # Convert labels to change points and then to segments
    gt_cps = labels_to_change_points(ground_truth_labels)
    pred_cps = labels_to_change_points(predicted_labels)
    
    gt_segments = compute_segments(gt_cps)
    pred_segments = compute_segments(pred_cps)
    
    covering = 0

    # Iterate over ground truth segments
    for gt_start, gt_end in gt_segments:
        gt_segment = set(range(gt_start, gt_end))
        segment_size = len(gt_segment)
        
        # Compute max IoU with any predicted segment
        max_iou = 0
        for pred_start, pred_end in pred_segments:
            pred_segment = set(range(pred_start, pred_end))
            
            intersection = len(gt_segment & pred_segment)
            union = len(gt_segment | pred_segment)
            iou = intersection / union if union > 0 else 0
            
            max_iou = max(max_iou, iou)
        
        # Weighted sum contribution
        covering += segment_size * max_iou
    
    return covering / n

def covering(ground_truth_labels, predicted_labels):
    """
    Compute the covering score for segmentation using an optimized approach.
    
    Parameters:
        ground_truth_labels (list or np.array): Ground truth labels.
        predicted_labels (list or np.array): Predicted labels.
    
    Returns:
        float: Covering score.
    """
    n = len(ground_truth_labels)
    
    # Convert labels to change points and then to segments
    gt_cps = labels_to_change_points(ground_truth_labels)
    pred_cps = labels_to_change_points(predicted_labels)
    
    gt_segments = compute_segments(gt_cps)
    pred_segments = compute_segments(pred_cps)
    
    covering = 0.0
    p_idx = 0
    p_len = len(pred_segments)
    
    # Iterate over ground truth segments (each represented as [gt_start, gt_end))
    for gt_start, gt_end in gt_segments:
        segment_size = gt_end - gt_start
        max_iou = 0.0
        
        # Advance the pointer in predicted segments until the current segment might overlap
        while p_idx < p_len and pred_segments[p_idx][1] <= gt_start:
            p_idx += 1
        
        # Use a temporary pointer to check all predicted segments that overlap with the ground truth segment
        temp_idx = p_idx
        while temp_idx < p_len and pred_segments[temp_idx][0] < gt_end:
            pred_start, pred_end = pred_segments[temp_idx]
            
            # Calculate intersection and union without constructing sets
            inter = max(0, min(gt_end, pred_end) - max(gt_start, pred_start))
            union = (gt_end - gt_start) + (pred_end - pred_start) - inter
            iou = inter / union if union > 0 else 0.0
            
            max_iou = max(max_iou, iou)
            temp_idx += 1
        
        # Weight the IoU by the segment's length
        covering += segment_size * max_iou
    
    return covering / n


'''
WARI & WNMI scores
Code adapted from scikit-learn original implementation
https://github.com/scikit-learn/scikit-learn/blob/98ed9dc73a86f5f11781a0e21f24c8f47979ec67/sklearn/metrics/cluster/_supervised.py
Authors: The scikit-learn developers
SPDX-License-Identifier: BSD-3-Clause
'''

#------------------------------------------------------
# Weighted Adjusted Rand Index (WARI)
#------------------------------------------------------

def compute_boundary_distances(labels):
    """
    Compute the distance from each point to the nearest change point (boundary)
    in the 1D label sequence.
    """
    n = len(labels)
    # Identify change points where label changes
    boundaries = np.where(np.diff(labels) != 0)[0]  # Identify change points
    boundaries = np.concatenate([boundaries, boundaries + 1])  # Add the next point for each change point
    boundaries = np.sort(boundaries)
    boundaries = np.concatenate([[0], boundaries, [n-1]])  # Add start and end points
    # if len(boundaries) == 0:
    #     return np.full(n, n)  # No boundaries: every point is maximally interior
    indices = np.arange(n)
    pos = np.searchsorted(boundaries, indices)
    distances = np.empty(n, dtype=float)
    
    # For indices before the first boundary:
    mask = (pos == 0)
    distances[mask] = boundaries[0] - indices[mask]
    
    # For indices after the last boundary:
    mask = (pos == len(boundaries))
    distances[mask] = indices[mask] - boundaries[-1]
    
    # For indices in between boundaries:
    mask = (pos > 0) & (pos < len(boundaries))
    left = indices[mask] - boundaries[pos[mask] - 1]
    right = boundaries[pos[mask]] - indices[mask]
    distances[mask] = np.minimum(left, right)
    
    return distances

def linear_distance(distances, alpha=0.1):
    """
    Compute the linear distance transformation for boundary distances.
    """
    return 1 + alpha * distances

def weighted_contingency_matrix(labels_true, labels_pred, distance, *, eps=None, sparse=False, dtype=np.float64):
    """
    Build a weighted contingency matrix that describes the relationship between two partitions,
    weighting each sample by the associated weight (e.g., based on its distance to the boundary).
    
    Parameters
    ----------
    labels_true : array-like of shape (n_samples,)
        Ground truth labels.
    
    labels_pred : array-like of shape (n_samples,)
        Predicted labels (clustering to evaluate).
    
    eps : float, default=None
        If float, this value is added to all values in the matrix to avoid NaN propagation.
        If None, no adjustment is made.
    
    sparse : bool, default=False
        If True, returns a sparse CSR matrix.
    
    dtype : numeric type, default=np.float64
        Data type of the output.
    
    Returns
    -------
    contingency : {array-like, sparse}, shape=[n_classes_true, n_classes_pred]
        Weighted matrix such that :math:`C_{i,j}` is the sum of the weights of the samples 
        belonging to true class i and predicted cluster j.
    """
    labels_true = np.asarray(labels_true)
    labels_pred = np.asarray(labels_pred)
    
    # Compute boundary distances for both clusterings
    d_true = compute_boundary_distances(labels_true)
    #d_pred = compute_boundary_distances(labels_pred)
    
    # Compute per-point weights from each clustering and then average them.
    #w_true = distance(d_true)
    #w_pred = distance(d_pred)
    #weights = (w_true + w_pred) / 2.0  # symmetric weights for each point

    weights = distance(d_true)
    
    if eps is not None and sparse:
        raise ValueError("Cannot set 'eps' when sparse=True")
    
    classes, class_idx = np.unique(labels_true, return_inverse=True)
    clusters, cluster_idx = np.unique(labels_pred, return_inverse=True)
    n_classes = classes.shape[0]
    n_clusters = clusters.shape[0]
    
    # Build the weighted contingency matrix using coo_matrix.
    contingency = sp.coo_matrix(
        (weights, (class_idx, cluster_idx)),
        shape=(n_classes, n_clusters),
        dtype=dtype,
    )
    
    if sparse:
        contingency = contingency.tocsr()
        contingency.sum_duplicates()
    else:
        contingency = contingency.toarray()
        if eps is not None:
            contingency = contingency + eps
    return contingency, weights

def weighted_pair_confusion_matrix(labels_true, labels_pred, distance):
    """
    Compute the weighted pair confusion matrix from the weighted contingency matrix.
    
    For each sample, its weight w(i) is considered. The weighted contingency matrix
    is constructed such that each cell (i,j) contains the sum of the weights of the samples
    belonging to true class i and predicted cluster j.
    
    The notations used are as follows:
      - Let M be the weighted contingency matrix.
      - For each cell, M[i,j] = sum_{samples in (i,j)} w(i).
      - Let n_true = sum over rows (i.e., S(i) for each true class i), and n_pred = sum over columns.
    
    The quantities are calculated as follows:
      - total_weight = sum_{i} w(i) (weighted equivalent of n_samples)
      - sum_squares = sum of squares of all non-zero values in M.
    """
    # Build the weighted contingency matrix (sparse for faster computation)
    contingency, weights = weighted_contingency_matrix(labels_true, labels_pred, distance, sparse=True, dtype=np.float64)
    
    # Sum of total weights
    total_weight = np.sum(weights)
    
    # Weighted sums by row and column
    row_sum = np.ravel(contingency.sum(axis=1))  # sum for each true class
    col_sum = np.ravel(contingency.sum(axis=0))  # sum for each predicted cluster
    
    # Calculate the sum of squares of the entries in the contingency matrix
    sum_squares = np.sum(contingency.data**2)
    
    # Build the weighted pair confusion matrix
    C = np.empty((2, 2), dtype=np.float64)
    C[1, 1] = sum_squares - total_weight
    C[0, 1] = contingency.dot(col_sum).sum() - sum_squares
    C[1, 0] = contingency.transpose().dot(row_sum).sum() - sum_squares
    C[0, 0] = total_weight**2 - C[0, 1] - C[1, 0] - sum_squares
    
    return C

def weighted_rand_score(labels_true, labels_pred, weights):
    """
    Compute the weighted Rand Index (unadjusted) from the weighted pair confusion matrix.
    
    The score is defined as the ratio of the sum of agreements (i.e., the sum of the
    diagonals of the confusion matrix) to the total sum of weighted pairs.
    """
    C = weighted_pair_confusion_matrix(labels_true, labels_pred, weights)
    numerator = np.trace(C)
    denominator = np.sum(C)
    
    # Special cases: if no error is made or if there are no pairs (denom=0)
    if numerator == denominator or denominator == 0:
        return 1.0
    
    return numerator / denominator

def weighted_adjusted_rand_score(labels_true, labels_pred, distance=linear_distance):

    (tn, fp), (fn, tp) = weighted_pair_confusion_matrix(labels_true, labels_pred, distance)
    # convert to Python integer types, to avoid overflow or underflow
    tn, fp, fn, tp = int(tn), int(fp), int(fn), int(tp)

    # Special cases: empty data or full agreement
    if fn == 0 and fp == 0:
        return 1.0

    return 2.0 * (tp * tn - fn * fp) / ((tp + fn) * (fn + tn) + (tp + fp) * (fp + tn))

#------------------------------------------------------
# Weighted Normalized Mutual Info Score (WNMI)
#------------------------------------------------------

def weighted_normalized_mutual_info_score(labels_true, labels_pred, distance=linear_distance, *, average_method="arithmetic"):
    
    classes = np.unique(labels_true)
    clusters = np.unique(labels_pred)

    # Special limit cases: no clustering since the data is not split.
    # It corresponds to both labellings having zero entropy.
    # This is a perfect match hence return 1.0.
    if (
        classes.shape[0] == clusters.shape[0] == 1
        or classes.shape[0] == clusters.shape[0] == 0
    ):
        return 1.0

    contingency, _ = weighted_contingency_matrix(labels_true, labels_pred, distance=distance, sparse=True)
    contingency = contingency.astype(np.float64, copy=False)
    # Calculate the MI for the two clusterings
    mi = mutual_info_score(labels_true, labels_pred, contingency=contingency)

    # At this point mi = 0 can't be a perfect match (the special case of a single
    # cluster has been dealt with before). Hence, if mi = 0, the nmi must be 0 whatever
    # the normalization.
    if mi == 0:
        return 0.0

    # Calculate entropy for each labeling
    h_true, h_pred = entropy(labels_true), entropy(labels_pred)

    normalizer = _generalized_average(h_true, h_pred, average_method)
    return mi / normalizer

'''
CMS & SMS scores
'''

#------------------------------------------------------
# Common Matching Sequence (CMS)
#------------------------------------------------------

def minimal_reindexed(seq):
    """
    Computes the minimal reindexed sequence:
      1. Remove consecutive duplicates.
      2. Reindex by the order of first appearance.
    For example, [32, 12, 12, 31, 32] becomes [0, 1, 1, 2, 0] 
    → after removal: [32,12,31,32] → reindexed: [0,1,2,0].
    """
    if len(seq) == 0:
        return []
    # Remove consecutive duplicates.
    reduced = [seq[0]]
    for x in seq[1:]:
        if x != reduced[-1]:
            reduced.append(x)
    # Reindex: first appearance gets 0, next new value gets 1, etc.
    mapping = {}
    reindexed = []
    next_index = 0
    for x in reduced:
        if x not in mapping:
            mapping[x] = next_index
            next_index += 1
        reindexed.append(mapping[x])
    return reindexed

def get_change_points(lst):
    """
    Returns the list of indices where the value changes.
    For example, for [0,0,1,1,2] it returns [2,4].
    """
    cps = []
    for i in range(1, len(lst)):
        if lst[i] != lst[i - 1]:
            cps.append(i)
    return cps

def common_matching_sequence_naive(labels_true, labels_pred):
    """
    Brute force implementation.
    Iterates over all intervals [i, j] (with i < j) and counts
    if minimal_reindexed(labels_true[i:j+1]) equals minimal_reindexed(labels_pred[i:j+1]).
    Complexity: O(n^2) subintervals.
    """
    n = len(labels_true)
    count = 0
    for i in range(n - 1):
        for j in range(i + 1, n):
            if minimal_reindexed(labels_true[i:j+1]) == minimal_reindexed(labels_pred[i:j+1]):
                count += 1
    total_intervals = n * (n - 1) // 2
    return count / total_intervals

def common_matching_sequence(labels_true, labels_pred):
    """
    Optimized algorithm using the union of change points.
    
    1. Compute change points for each list.
    2. Define U = sorted({0} ∪ cps_true ∪ cps_pred ∪ {n}), where n = len(labels_true).
       These indices partition the list into blocks where values remain constant.
    3. For any original interval [i, j] (with i < j), let u = max{x in U : x <= i} and
       v = min{x in U : x > j}. Then the minimal reindexed sequence on [i, j]
       is the same as that computed on liste[u:v].
    4. For a given union interval [u, v] corresponding to some U[i] and U[j]:
         - If the union boundaries are consecutive (j == i+1), then the entire
           interval lies within one constant block. The number of intervals is 
           C(L,2) = L*(L-1)//2, where L = (U[i+1] - U[i]).
         - If they are not consecutive, then the free choices are:
             * i can be any index in [U[i], U[i+1]-1] and
             * j can be any index in [U[j-1], v-1].
           So the count is (U[i+1] - U[i]) * (v - U[j-1]).
    5. We add the count for a union interval only if the minimal reindexed sequences
       computed on labels_true[u:v] and labels_pred[u:v] match.
    6. Normalize the count by the total number of intervals.
    """
    n = len(labels_true)
    cps_true = get_change_points(labels_true)
    cps_pred = get_change_points(labels_pred)
    U = sorted(set([0] + cps_true + cps_pred + [n]))
    
    total_count = 0
    # Iterate over all pairs of union boundaries U[i] and U[j] with i < j.
    for i in range(len(U) - 1):
        for j in range(i + 1, len(U)):
            u, v = U[i], U[j]
            seg_true = labels_true[u:v]
            seg_pred = labels_pred[u:v]
            if minimal_reindexed(seg_true) == minimal_reindexed(seg_pred):
                if j == i + 1:
                    # Interval is contained within a constant block.
                    L = U[i+1] - U[i]
                    # Only intervals of length >= 2 count:
                    count_here = L * (L - 1) // 2
                else:
                    # For non-consecutive union boundaries, the start index can be any
                    # index in [U[i], U[i+1]-1] and the end index any in [U[j-1], U[j]-1].
                    count_here = (U[i+1] - U[i]) * (U[j] - U[j-1])
                total_count += count_here
    
    # Normalize by the total number of intervals
    total_intervals = n * (n - 1) // 2
    return total_count / total_intervals

def normalized_common_matching_sequence(labels_true, labels_pred, beta=50, center=0.5):
    """
    Compute a normalized version of the common matching sequence.
    
    This function applies a logistic transformation to the common matching sequence 
    to expand its effective range between 0 and 1.
    
    Parameters
    ----------
    labels_true : list or np.array
        Ground truth labels.
    labels_pred : list or np.array
        Predicted labels.
    beta : float, optional
        Steepness of the logistic function (default is 20). Higher values increase sensitivity.
    center : float, optional
        The center (midpoint) value of the common matching sequence that maps to 0.5 (default is 0.8).
    
    Returns
    -------
    float
        Normalized common matching sequence score in [0, 1].
    """
    cms = common_matching_sequence(labels_true, labels_pred)
    return 1 / (1 + np.exp(-beta * (cms - center)))

#------------------------------------------------------
# Edit distance
#------------------------------------------------------

from tools.edition import edit_measure

#------------------------------------------------------
# State Matching Score (SMS)
#------------------------------------------------------

def optimal_label_mapping(labels_true, labels_pred):
    """
    Compute an optimal mapping from predicted labels to true labels.
    
    The mapping is computed by building a confusion matrix between the unique
    labels in the true and predicted arrays, and then using the Hungarian algorithm
    to find the assignment that maximizes the total number of matching points.
    
    Parameters:
      labels_true: numpy array of ground truth labels.
      labels_pred: numpy array of predicted labels.
      
    Returns:
      mapping: dict such that mapping[pred_label] = true_label.
    """
    true_labels = np.unique(labels_true)
    pred_labels = np.unique(labels_pred)
    
    # Build confusion matrix: rows for true labels, columns for pred labels.
    C = np.zeros((len(true_labels), len(pred_labels)), dtype=int)
    for i, t in enumerate(true_labels):
        for j, p in enumerate(pred_labels):
            C[i, j] = np.sum((labels_true == t) & (labels_pred == p))
    
    # We want to maximize total overlap.
    # The Hungarian algorithm minimizes cost so we use -C.
    row_ind, col_ind = linear_sum_assignment(-C)
    mapping = {}
    for i, j in zip(row_ind, col_ind):
        mapping[pred_labels[j]] = true_labels[i]
    return mapping

def apply_mapping(labels_pred, mapping):
    """
    Apply the optimal mapping to predicted labels.
    """
    # If a predicted label is not in the mapping, leave it unchanged.
    return np.array([mapping.get(x, x) for x in labels_pred])

def compute_boundaries(labels):
    """
    Compute boundaries (indices where the label changes).
    
    A boundary is defined as the index at which the new segment starts.
    """
    boundaries = []
    for i in range(1, len(labels)):
        if labels[i] != labels[i-1]:
            boundaries.append(i)
    return boundaries

def boundary_delay_cost(true_boundaries, pred_boundaries, delta, alpha):
    """
    Compute the boundary delay cost C_D.
    
    For each true boundary, find the distance to the closest predicted boundary.
    If the absolute distance is within delta, no penalty is incurred.
    Otherwise, add a penalty proportional to (|d| - delta) with factor alpha.
    """
    cost = 0.0
    for b in true_boundaries:
        if not pred_boundaries:
            d = b  # if no predicted boundaries exist
        else:
            d = min(abs(b - pb) for pb in pred_boundaries)
        if d > delta:
            cost += alpha * (d - delta)
    return cost

def fragmentation_cost(labels_true, labels_pred, beta):
    """
    Compute the fragmentation cost C_F.
    
    For each contiguous true segment in labels_true, count how many predicted segments 
    appear in that segment. Add beta*(k - 1) as a penalty if k > 1.
    """
    cost = 0.0
    n = len(labels_true)
    start = 0
    while start < n:
        current_label = labels_true[start]
        end = start
        while end + 1 < n and labels_true[end + 1] == current_label:
            end += 1
        # Extract the predicted labels for this true segment.
        pred_segment = labels_pred[start:end+1]
        # Count the number of contiguous groups in the predicted segment.
        k = 1
        for i in range(1, len(pred_segment)):
            if pred_segment[i] != pred_segment[i-1]:
                k += 1
        cost += k ** 2
        start = end + 1
    return cost

def misclassification_cost(labels_true, labels_pred, true_boundaries, gamma):
    """
    Compute the misclassification cost C_M.
    
    For every index where labels_true and labels_pred differ, add a cost:
      1 + gamma * (distance to the closest true boundary)
    """
    cost = 0.0
    n = len(labels_true)
    for i in range(n):
        if labels_true[i] != labels_pred[i]:
            if true_boundaries:
                d = min(abs(i - b) for b in true_boundaries)
            else:
                d = n  # if no boundaries, assign maximal distance
            cost += 1 + gamma * d/len(labels_true)
    return cost

def state_matching_score_old(labels_true, labels_pred,
                        w_M=1.0, w_D=0.0, w_F=1.0,
                        gamma=100.0, alpha=1.0, beta=10.0, delta=0.0,
                        scale=None,
                        return_mapping=False):
    """
    Compute the State Matching Score between two clusterings.
    
    This function first computes an optimal mapping from the predicted labels to the true labels,
    so that class IDs can differ between the two clusterings. Then, it calculates three cost 
    components: misclassification, boundary delay, and fragmentation. These are aggregated into a 
    Weighted Segmentation Error (WSE) which is normalized to return a score between 0 and 1, 
    with 1 indicating a perfect match.
    
    Parameters:
      - labels_true: ground truth labels (list or array)
      - labels_pred: predicted labels (list or array)
      - w_M: weight for misclassification cost C_M
      - w_D: weight for boundary delay cost C_D
      - w_F: weight for fragmentation cost C_F
      - gamma: weight for distance in misclassification cost
      - alpha: penalty factor for boundary delay (beyond delta)
      - beta: penalty factor for fragmentation (per extra predicted segment)
      - delta: tolerance window for boundary delays (points within delta are not penalized)
      - scale: normalization factor (if None, defaults to the number of points)
    
    Returns:
      - score: a value between 0 and 1, with 1 being a perfect match.
    """
    if len(labels_true) != len(labels_pred):
        raise ValueError("labels_true and labels_pred must have the same length.")
    
    # Convert to numpy arrays.
    labels_true = np.array(labels_true)
    labels_pred = np.array(labels_pred)
    
    # Map predicted labels to true labels.
    mapping = optimal_label_mapping(labels_true, labels_pred)
    mapped_pred = apply_mapping(labels_pred, mapping)

    # Compute boundaries for true and mapped predicted labels.
    true_boundaries = compute_boundaries(labels_true)
    #pred_boundaries = compute_boundaries(mapped_pred)

    # Compute gamma based on the ratio of average cluster size to the total length
    unique_labels, counts = np.unique(labels_true, return_counts=True)
    average_cluster_size = np.mean(counts)
    gamma = 5. * len(labels_true) / average_cluster_size * 5.
    
    # Compute cost components.
    C_M = misclassification_cost(labels_true, mapped_pred, true_boundaries, gamma)
    #C_D = boundary_delay_cost(true_boundaries, pred_boundaries, delta, alpha)
    #C_F = fragmentation_cost(labels_true, mapped_pred, beta)
    
    # Aggregate the costs into the raw error.
    #WSE = w_M * C_M + w_D * C_D + w_F * C_F
    WSE = w_M * C_M
    
    # Normalize the error into a score between 0 and 1.
    # Here we use a scaling factor: if not provided, default to the length of the sequence.

    if scale is None:
        scale = len(labels_true)
    # error_weight = 2.0  # weight for the error term
    # score = 1 / (1 + error_weight * WSE / scale)
    #score = (len(labels_true) - WSE) / len(labels_true)  # Normalize to [0, 1]
    score = 1 / (1 + (WSE / scale) ** 2)
    if return_mapping:
        return score, mapped_pred
    return score


#------------------------------------------------------
# New SMS
#------------------------------------------------------

def map_predicted_labels(labels_true, labels_pred):
    """
    Maps predicted labels to match true labels using the Hungarian algorithm,
    ensuring the number of unique output labels equals the number of unique
    input predicted labels.

    Parameters:
        labels_true: numpy array of ground truth labels.
        labels_pred: numpy array of predicted labels.

    Returns:
        mapped_pred: numpy array of predicted labels after mapping.
    """
    labels_true = np.asarray(labels_true)
    labels_pred = np.asarray(labels_pred)
    original_shape = labels_pred.shape

    if labels_pred.size == 0:
        return np.array([])

    all_unique_pred = np.unique(labels_pred)

    # Handle cases where true labels are empty or comparison is not possible
    if labels_true.size == 0:
        mapping = {label: i for i, label in enumerate(all_unique_pred)}
        mapped_pred_flat = np.array([mapping[val] for val in labels_pred.ravel()])
        return mapped_pred_flat.reshape(original_shape)

    # Determine common length for comparison
    compare_len = min(len(labels_pred.ravel()), len(labels_true.ravel()))
    if compare_len == 0: # No overlap to compare
        mapping = {label: i for i, label in enumerate(all_unique_pred)}
        mapped_pred_flat = np.array([mapping[val] for val in labels_pred.ravel()])
        return mapped_pred_flat.reshape(original_shape)

    true_comp = labels_true.ravel()[:compare_len]
    pred_comp = labels_pred.ravel()[:compare_len]

    unique_pred_comp = np.unique(pred_comp)
    unique_true_comp = np.unique(true_comp)

    # Cost matrix: negative overlap
    cost_matrix = np.zeros((len(unique_pred_comp), len(unique_true_comp)))
    for i, p_label in enumerate(unique_pred_comp):
        for j, t_label in enumerate(unique_true_comp):
            overlap = np.sum((pred_comp == p_label) & (true_comp == t_label))
            cost_matrix[i, j] = -overlap

    # Hungarian algorithm for optimal assignment
    row_ind, col_ind = linear_sum_assignment(cost_matrix)
    hungarian_map = {unique_pred_comp[i]: unique_true_comp[j] for i, j in zip(row_ind, col_ind)}

    # Build the final mapping ensuring unique outputs for all unique predicted labels
    final_map = {}
    used_targets = set()

    # 1. Apply Hungarian assignments where the target is available
    for p_label, t_label in hungarian_map.items():
        if t_label not in used_targets:
            final_map[p_label] = t_label
            used_targets.add(t_label)
        # else: Target taken, p_label will be handled in step 2

    # 2. Assign remaining unique predicted labels
    next_new_label = 0
    for p_label in all_unique_pred:
        if p_label not in final_map: # If not assigned yet
            # Try assigning p_label to itself if available
            if p_label not in used_targets:
                final_map[p_label] = p_label
                used_targets.add(p_label)
            # Otherwise, find the next available non-negative integer
            else:
                while next_new_label in used_targets:
                    next_new_label += 1
                final_map[p_label] = next_new_label
                used_targets.add(next_new_label)

    # Apply the final map to the original full predicted sequence
    mapped_pred_flat = np.array([final_map[val] for val in labels_pred.ravel()])
    mapped_pred = mapped_pred_flat.reshape(original_shape)

    return mapped_pred

def error_type(error_label, true_atomicity, p0, p1, t0, t1):
    if true_atomicity == 1:
        # Delay
        # Check if the predicted error label matches either the preceding or succeeding true label.
        if (t0 is not None and p0 is not None and t0 == error_label and p0 == error_label) or (t1 is not None and p1 is not None and t1 == error_label and p1 == error_label):
            return "delay"
        
        # Isolation
        else:
            return "isolation"

    elif true_atomicity == 2:
    # Transition
    # True labels contains two different labels.
        return "transition"

    elif true_atomicity > 2:
        # Missing
        # True labels contain more than two different labels.
        return "missing"

def nearest_block_boundary_distance(true_boundaries, block_start, block_end):
    """
    Computes the distance from the center of an error block to the nearest true boundary.

    Parameters:
        true_boundaries: List or numpy array of indices where true labels change.
        block_start: Start index of the error block.
        block_end: End index of the error block (inclusive).

    Returns:
        float: The minimum distance from the block center to a true boundary.
    """
    true_boundaries = np.asarray(true_boundaries)
    center = (block_start + block_end) / 2.0
    distances = np.abs(true_boundaries - center)
    min_dist = np.min(distances)

    return min_dist

def compute_boundaries_symmetrical(labels):
    """
    Computes the indices of the boundaries in the label sequence.
    
    Parameters:
        labels: numpy array of labels.
    
    Returns:
        List of indices where the label changes.
    """
    boundaries = []
    for i in range(1, len(labels)):
        if labels[i] != labels[i-1]:
            #boundaries.append(i-1)
            boundaries.append(i)
    return boundaries

def reduced_labels(sequence):
    # Remove consecutive duplicates while preserving order
    if len(sequence) > 0:
        reduced_segment = [sequence[0]]
        for x in sequence[1:]:
            if x != reduced_segment[-1]:
                reduced_segment.append(x)
    return reduced_segment

def atomicity(sequence):
    # Remove consecutive duplicates while preserving order
    if len(sequence) > 0:
        reduced_segment = [sequence[0]]
        for x in sequence[1:]:
            if x != reduced_segment[-1]:
                reduced_segment.append(x)
        sequence_atomicity = len(reduced_segment)
    else:
        sequence_atomicity = 0
    return sequence_atomicity

def state_matching_score(labels_true, labels_pred, weights={'delay': 0.1,
                                                            'transition': 0.3,
                                                            'isolation': 0.8,
                                                            'missing': 0.5}, return_mapped=False, return_errors=False):
    """
    Computes a new State Matching Score (SMS) based on identifying and classifying
    error segments between true and predicted label sequences after optimal mapping.

    The function first maps predicted labels to true labels using an optimal
    assignment strategy. It then iterates through the sequences, identifying
    contiguous segments where the mapped predicted label differs from the true label
    and the predicted label within the segment is constant.

    Each error segment is classified into types ('delay', 'transition', 'isolation',
    'missing'). A weighted error score is calculated based on
    segment size, error type, distance to true boundaries, and segment atomicity.
    The penalty for each error type is determined by the input `weights` dictionary.

    The intended severity hierarchy for error types, from least to most severe, is
    typically: delay, transition, missing, isolation.
    The final score is normalized, where higher values indicate better agreement.

    Parameters:
        labels_true (array-like): Ground truth labels.
        labels_pred (array-like): Predicted labels.
        weights (dict): A dictionary mapping error type strings
                        ('delay', 'transition', 'isolation', 'missing')
                        to their respective penalty weights, reflecting their severity.
        return_mapped (bool, optional): If True, return the mapped predicted labels. Defaults to False.
        return_errors (bool, optional): If True, return a list of detected errors with details. Defaults to False.

    Returns:
        float or tuple:
            - If return_mapped is False and return_errors is False: The normalized State Matching Score.
            - If return_mapped is True and return_errors is False: (score, mapped_pred).
            - If return_mapped is False and return_errors is True: (score, errors_list).
            - If return_mapped is True and return_errors is True: (score, mapped_pred, errors_list).
            Returns None if input is empty.
    """
    n = len(labels_true)
    if n == 0:
        return None # Return None for empty input

    # Map predicted labels to true labels
    mapped_pred = map_predicted_labels(labels_true, labels_pred)
    true_boundaries = np.unique([0] + compute_boundaries_symmetrical(labels_true) + [n])

    i = 0
    total_penalty = 0.0 # Renamed from error_score for clarity, represents the sum of penalties
    total_error_length = 0
    errors_list = [] if return_errors else None

    while i < n:
        if labels_true[i] != mapped_pred[i]:
            # Start of a potential error segment
            start_index = i
            error_label = mapped_pred[i]
            j = i + 1
            # Extend the segment as long as the error persists with the same predicted label
            while j < n and labels_true[j] != mapped_pred[j] and mapped_pred[j] == error_label:
                j += 1
            end_index = j - 1

            # Extract the segment of true labels corresponding to the error segment
            true_labels_segment = np.asarray(labels_true[start_index : end_index + 1])
            true_atomicity = atomicity(true_labels_segment)

            # Calculate segment size
            segment_size = end_index - start_index + 1
            total_error_length += segment_size

            # Determine neighbor values for predicted labels
            p0 = mapped_pred[start_index - 1] if start_index > 0 else None
            p1 = mapped_pred[end_index + 1] if end_index < n - 1 else None

            # Determine neighbor values for true labels
            t0 = labels_true[start_index - 1] if start_index > 0 else None
            t1 = labels_true[end_index + 1] if end_index < n - 1 else None

            # Call the error_type function with the required arguments
            err_type = error_type(error_label, true_atomicity, p0, p1, t0, t1)

            segment_penalty = 0.0
            weight = weights.get(err_type, 1.0) # Default weight if type not in dict

            if err_type == "delay":
                segment_penalty = weight * segment_size

            elif err_type == "transition" or err_type == "isolation":
                # Adjust the score based on the distance to the nearest true boundary
                # Nearest distance is at most 1/2 of the segment size
                min_dist = 2 * nearest_block_boundary_distance(true_boundaries, start_index, end_index) / n
                segment_penalty = weight * min_dist * segment_size

            elif err_type == "missing":
                
                #atomicity_penalty = 1 + (weight - 1) * (1 - 1 / true_atomicity) if weight != 1 else 1

                # Adjust the score based on the number of missed true labels. We want the penalty to:
                # - increase as true_atomicity increases
                # - be equal to the weight when true_atomicity is minimal (i.e. true_atomicity = 3 according to the definition)
                # - tend to 1 when true_atomicity tends to infinity
                atomicity_penalty = 1.0 + (weight - 1.0) * (3.0 / true_atomicity)

                segment_penalty = weight * segment_size * atomicity_penalty

            total_penalty += segment_penalty

            if return_errors:
                errors_list.append({
                    'type': err_type,
                    'start': start_index,
                    'end': end_index,
                    'size': segment_size,
                    'penalty': segment_penalty # Store the calculated penalty for this segment
                })

            # Move the main loop index past this segment
            i = j
        else:
            # No error at this index, move to the next
            i += 1

    # Calculate the final score
    # The total error is the length of incorrect points plus the weighted penalty
    total_weighted_error = total_error_length + total_penalty
    score = max(0.0, 1.0 - total_weighted_error / n) # Ensure score is not negative

    # Return based on flags
    if return_mapped and return_errors:
        return score, mapped_pred, errors_list
    elif return_mapped:
        return score, mapped_pred
    elif return_errors:
        return score, errors_list
    else:
        return score
